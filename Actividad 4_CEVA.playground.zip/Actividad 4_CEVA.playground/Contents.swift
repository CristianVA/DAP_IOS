//: Playground - noun: a place where people can play

import UIKit

var datos:Array = [3,6,9,2,4,1]

for datos in datos{
    if datos < 5{
        print (datos)
    }
}

func suma (n1:Int,n2:Int)-> Int{
    return n1+n2*(n2);
}

enum meses {
    case Enero
    case Febrero
    case Marzo
    case Abril
    case Mayo
    case Junio
    case Julio
    case Agosto
    case Septiembre
    case Octubre
    case Noviembre
    case Diciembre
}
var numeroMes:meses
numeroMes = .Enero
numeroMes = .Febrero
numeroMes = .Marzo
numeroMes = .Abril
numeroMes = .Mayo
numeroMes = .Junio
numeroMes = .Julio
numeroMes = .Agosto
numeroMes = .Septiembre
numeroMes = .Octubre
numeroMes = .Noviembre
numeroMes = .Diciembre

switch numeroMes {
case .Enero:
    print("1")
    break;
    
case.Febrero:
    print("2")
    break:
    
case .Marzo:
    print("3")
    break;
    
case .Abril:
    print("4")
    break;
    
case .Mayo:
    print("5")
    break;
    
case .Junio:
    print("6")
    break;
    
case .Julio:
    print("7")
    break;
    
case .Agosto:
    print("8")
    break;

case .Septiembre:
    print("9")
    break;

case .Octubre:
    print("10")
    break;

case .Noviembre:
    print("11")
    break;
    
case .Diciembre:
    print("12")
    break;
    
default:
    print("Hola :3")
}
