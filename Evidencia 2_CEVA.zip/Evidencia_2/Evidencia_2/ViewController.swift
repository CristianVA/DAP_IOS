//
//  ViewController.swift
//  Evidencia_2
//
//  Created by Cristian Varela on 28/10/21.
//  Copyright © 2021 Cristian Varela. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

