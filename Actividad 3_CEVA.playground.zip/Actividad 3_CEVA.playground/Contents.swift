import UIKit
/*:
# Playground - Actividad 3
* Tipos de datos
* Asociación de tipos
* Arreglos y Diccionarios
*/


/*: 
### Actividad de Tipos de datos
A) Declarar cuatro variables con tres diferentes tipos de datos, cada uno que corresponda a una numero entero, un numero decimal (flotante), una cadena de texto, realizando la asignación explicita y la asignación inferida
*/
var V0:String = ":)"
var V1:Int = 10
var V2:Float = 10.5
var V3:Bool = false
/*:
### Asociación de tipos
A) Declara el tipo de dato por asociación para un tipo de dato String
*/
V0 = "Variable tipo string"
//: B) Declara el tipo de dato por asociación para un tipo de dato  Número entero.
var N1:Int = 5
var N2:Int = 10
var N3:Int = 15
/*: 
### Arreglos y Diccionarios
A) Crea la variable "numeros" de tipo Array con números consecutivos del 1 a 10.
*/
var numeros:Array<Int> = Array <Int>()
numeros.append(1)
numeros.append(2)
numeros.append(3)
numeros.append(4)
numeros.append(5)
numeros.append(6)
numeros.append(7)
numeros.append(8)
numeros.append(9)
numeros.append(10)
//: B) Crea la variable "diasSemana" de tipo Dictionary con la relación numero:día Ej. 1:"Lunes"
var diasSemana:Dictionary<String, Int> = Dictionary<String, Int>()
diasSemana = ["Lunes":0]
diasSemana = ["Martes":1]
diasSemana = ["Miércoles":2]
diasSemana = ["Jueves":3]
diasSemana = ["Viernes":4]
diasSemana = ["Sábado":5]
diasSemana = ["Domingo":6]
print ("Días de la semana: \(diasSemana)")
/*:
### Condicionales y Ciclos
A) Declarar la variable "datos" con los valores [3,6,9,2,4,1]
*/
var datos:Array = [3,6,9,2,4,1]
//: B) realizar el recorrido de la variable "datos" con la instrucción "for"
for datos in datos{
    print (datos)
}

//: C) Encontrar los valores menores a 5




