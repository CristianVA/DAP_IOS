import UIKit

infix operator |>

func |> (a:Int, b:(Int)->Int)->Int
{
    return b(a)
}

let numeros =[2,3,4,5]

class nums
{
    var Valores:[Int]
    init(v:[Int])
    {
        self.Valores = Valores
        
        subscript(idx:Int)->Int
        {
            get
            {
                return Valores[idx]
                
                set(2,3,4,5*2)
            }
        }
    }
}



let errores = [1:"A", 2:"B", 3:"C"]

func Existe(idx:Int)
{
    guard let existe = errores [idx] else{
        print ("No existe")
        return
    }
    print("existe\(existe)")
}
Existe(idx:5)
errores[5]
