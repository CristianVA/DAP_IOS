//: Playground - noun: a place where people can play

import UIKit

class Persona{
    var nombre = ""
    var pies:Int = 0
    
    func Saludar(mensaje:String){
        self.nombre = mensaje + "Mucho gusto"
    }   //Function End
    
    func Caminar(pasos:Int){
        self.pies = pasos
        switch pasos {  //  SWITCH
            
        case 0:
            print("No se han dado pasos")
            break;
            
        case 1:
            print("Se ha dado un paso")
            break;
            
        case 2:
            print("Se han dado dos pasos")
            break;
            
        case 3:
            print("Se han dado tres pasos")
            break;
            
        case 4:
            print("Se han dado cuatro pasos")
            break;
            
        case 5:
            print("Se han dado cinco pasos")
            break;
            
        case 6:
            print("Se han dado seis pasos")
            break;
            
        case 7:
            print("Se han dado siete pasos")
            break;
            
        case 8:
            print("Se han dado ocho pasos")
            break;
            
        case 9:
            print("Se han dado nueve pasos")
            break;
            
        case 10:
            print("Se han dado diez pasos")
            break;
        
        default:
            print("Se han dado más de diez pasos")
            break;
        }   // Switch End
    }   //Function End
    
    //  Declaración del struct
    struct Video {
        var alto:Int
        var ancho:Int
        init(alto:Int,ancho:Int) {
            self.alto = alto
            self.ancho = ancho
        }
        func QueResolucion() -> (Int,Int) {
            return (self.alto,self.ancho)
        }
    }
    
    // Instancia en instalación
    var hd = Video(alto:1024, ancho:768)
    //  Aplicación de Struct
    var vga = Video(alto: 480, ancho: 640)
    
    hd.QueResolucion()
    vga.QueResolucion()
    
    //  Declaración extensión
    extension Int{
        var horas:Int{
            return self *60
        }
        func segundos()->Int{
            return self *3600
        }
    }
    
    
    
}
